package hospital.ui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Component;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;

import hospital.business.Patient;
import hospital.db.PatientDB;
import hospital.db.DBException;

import java.sql.Date;
import java.text.DateFormat;
/**
 *
 * @author junthearith
 */
public class PatientForm extends JDialog {
    private JTextField patientIdField;
    private JTextField firstNameField;
    private JTextField lastNameField;
    private JTextField sexField;
    private JTextField ageField;
    private JTextField dobField;
    private JTextField maritalStatusField;
    private JTextField addressField;
    private JTextField roomField;
    private JTextField regiDateField;
    private JTextField phoneNumberField;
    private JTextField contactField;
    private JButton confirmButton;
    private JButton cancelButton;
    
    private Patient patient = new Patient();
    
    public PatientForm(java.awt.Frame parent, String title, boolean modal) {
        super(parent, title, modal);
        initComponents();
    }
    
    public PatientForm(java.awt.Frame parent, String title, boolean modal, 
            Patient patient) {
        this(parent, title, modal);
        this.patient = patient;
        confirmButton.setText("Save");
        // set Data to textField
        patientIdField.setText(Integer.toString(patient.getId()));
        firstNameField.setText(patient.getFirstName());
        lastNameField.setText(patient.getLastName());
        sexField.setText(patient.getSex());
        ageField.setText(Integer.toString(patient.getAge()));
        dobField.setText(patient.getStringDOB());
        maritalStatusField.setText(patient.getMaritalStatus());
        addressField.setText(patient.getAddress());
        roomField.setText(patient.getRoom());
        regiDateField.setText(patient.getStringRegiDate());
        phoneNumberField.setText(Long.toString(patient.getPhoneNumber()));
        contactField.setText(Long.toString(patient.getContact()));
        patientIdField.setEditable(false);
    }
    
    private void initComponents() {
        patientIdField = new JTextField();
        firstNameField = new JTextField();
        lastNameField = new JTextField();
        sexField = new JTextField();
        ageField = new JTextField();
        dobField = new JTextField();
        maritalStatusField = new JTextField();
        addressField = new JTextField();
        roomField = new JTextField();
        regiDateField = new JTextField();
        phoneNumberField = new JTextField();
        contactField = new JTextField();
        confirmButton = new JButton();
        cancelButton = new JButton();
        
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        
        Dimension shortField = new Dimension(150, 20);
        Dimension longField = new Dimension(200, 20);
        
        patientIdField.setPreferredSize(shortField);
        patientIdField.setMinimumSize(shortField);
        firstNameField.setPreferredSize(longField);
        firstNameField.setMinimumSize(longField);
        lastNameField.setPreferredSize(longField);
        lastNameField.setMinimumSize(longField);
        sexField.setPreferredSize(shortField);
        sexField.setMinimumSize(shortField);
        ageField.setPreferredSize(shortField);
        ageField.setMinimumSize(shortField);
        dobField.setPreferredSize(longField);
        dobField.setMinimumSize(longField);
        maritalStatusField.setPreferredSize(longField);
        maritalStatusField.setMinimumSize(longField);
        addressField.setPreferredSize(longField);
        addressField.setMinimumSize(longField);
        roomField.setPreferredSize(shortField);
        roomField.setMinimumSize(shortField);
        regiDateField.setPreferredSize(longField);
        regiDateField.setMinimumSize(longField);
        phoneNumberField.setPreferredSize(longField);
        phoneNumberField.setMinimumSize(longField);
        contactField.setPreferredSize(longField);
        contactField.setMinimumSize(longField);
        
        
        cancelButton.setText("Cancel");
        cancelButton.addActionListener((ActionEvent) -> {
            cancelButtonActionPerformed();
        });
        
        confirmButton.setText("Add");
        confirmButton.addActionListener((ActionEvent) -> {
            confirmButtonActionPerformed();
        });
        
        JPanel patientPanel = new JPanel();
        patientPanel.setLayout(new GridBagLayout());
        patientPanel.add(new JLabel("ID:"),
                getConstraints(0, 0, GridBagConstraints.LINE_START));
        patientPanel.add(patientIdField,
                getConstraints(1, 0, GridBagConstraints.LINE_START));
        patientPanel.add(new JLabel("FirstName:"),
                getConstraints(0, 1, GridBagConstraints.LINE_START));
        patientPanel.add(firstNameField,
                getConstraints(1, 1, GridBagConstraints.LINE_START));
        patientPanel.add(new JLabel("LastName:"), 
                getConstraints(0, 2, GridBagConstraints.LINE_START));
        patientPanel.add(lastNameField, 
                getConstraints(1, 2, GridBagConstraints.LINE_START));
        patientPanel.add(new JLabel("Sex:"), 
                getConstraints(0, 3, GridBagConstraints.LINE_START));
        patientPanel.add(sexField, 
                getConstraints(1, 3, GridBagConstraints.LINE_START));
        patientPanel.add(new JLabel("Age:"), 
                getConstraints(0, 4, GridBagConstraints.LINE_START));
        patientPanel.add(ageField, 
                getConstraints(1, 4, GridBagConstraints.LINE_START));
        patientPanel.add(new JLabel("DOB(yyyy-mm-dd):"), 
                getConstraints(0, 5, GridBagConstraints.LINE_START));
        patientPanel.add(dobField, 
                getConstraints(1, 5, GridBagConstraints.LINE_START));
        patientPanel.add(new JLabel("MaritalStatus:"), 
                getConstraints(3, 0, GridBagConstraints.LINE_START));
        patientPanel.add(maritalStatusField, 
                getConstraints(4, 0, GridBagConstraints.LINE_START));
        patientPanel.add(new JLabel("Address:"), 
                getConstraints(3, 1, GridBagConstraints.LINE_START));
        patientPanel.add(addressField, 
                getConstraints(4, 1, GridBagConstraints.LINE_START));
        patientPanel.add(new JLabel("Room:"), 
                getConstraints(3, 2, GridBagConstraints.LINE_START));
        patientPanel.add(roomField, 
                getConstraints(4, 2, GridBagConstraints.LINE_START));
        patientPanel.add(new JLabel("RegistrationDate(yyyy-mm-dd):"), 
                getConstraints(3, 3, GridBagConstraints.LINE_START));
        patientPanel.add(regiDateField, 
                getConstraints(4, 3, GridBagConstraints.LINE_START));
        patientPanel.add(new JLabel("PhoneNumber:"), 
                getConstraints(3, 4, GridBagConstraints.LINE_START));
        patientPanel.add(phoneNumberField, 
                getConstraints(4, 4, GridBagConstraints.LINE_START));
        patientPanel.add(new JLabel("Contact:"), 
                getConstraints(3, 5, GridBagConstraints.LINE_START));
        patientPanel.add(contactField, 
                getConstraints(4, 5, GridBagConstraints.LINE_START));
        
        // JButton panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(confirmButton);
        buttonPanel.add(cancelButton);
        
        // add panel to main panel
        setLayout(new BorderLayout());
        add(patientPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        pack();
    }
    
    private GridBagConstraints getConstraints(int x, int y, int anchor) {
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5, 5, 0, 5);
        c.gridx = x; c.gridy = y; c.anchor = anchor;
        return c;
    }
    
    private void cancelButtonActionPerformed() {
        dispose();
    }
    
    private void confirmButtonActionPerformed() {
        if (isValidDateData()) {
            setData();
            if (confirmButton.getText().equals("Add")) {
                doAdd();
            } else {
                doEdit();
            }
        }
    }
    
    private boolean isValidDateData() {
        String idString = patientIdField.getText();
        String fname = firstNameField.getText();
        String lname = lastNameField.getText();
        String sex = sexField.getText();
        String ageString = ageField.getText();
        String dobString = dobField.getText();
        String maritalStatus = maritalStatusField.getText();
        String address = addressField.getText();
        String room = roomField.getText();
        String regiDateString = regiDateField.getText();
        String phoneNumString = phoneNumberField.getText();
        String contactString = contactField.getText();
        
        if (idString == null || fname == null || lname == null || sex == null || 
                ageString == null || dobString == null || maritalStatus == null ||
                address == null || room == null || regiDateString == null || 
                phoneNumString == null || contactString == null || idString.isEmpty() || 
                fname.isEmpty() || lname.isEmpty() || sex.isEmpty() || ageString.isEmpty() || 
                dobString.isEmpty() || maritalStatus.isEmpty() || address.isEmpty() || 
                room.isEmpty() || regiDateString.isEmpty() || phoneNumString.isEmpty() || 
                contactString.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.", 
                    "Missing Fields", JOptionPane.INFORMATION_MESSAGE);
            return false;
        } 
        else {
            try {
                int age = Integer.parseInt(ageString);
                long phoneNum = Long.parseLong(phoneNumString);
                long contact = Long.parseLong(contactString);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, 
                        "This data entered is invalid.", 
                        "Invalid Data", JOptionPane.INFORMATION_MESSAGE);
                //requestFocusInWindow();
                return false;
            }
            
            try {
                Date DOB = Date.valueOf(dobString);
                Date regiDate = Date.valueOf(regiDateString);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, 
                        "This LocalDate parse entered is invalid.", 
                        "LocalDate parse Invalid.", JOptionPane.INFORMATION_MESSAGE);
                //requestFocusInWindow();
                return false;
            }
        }
        return true;
    }
    
    private void setData() {
        String idString = patientIdField.getText();
        String fname = firstNameField.getText();
        String lname = lastNameField.getText();
        String sex = sexField.getText();
        String ageString = ageField.getText();
        String dobString = dobField.getText();
        String maritalStatus = maritalStatusField.getText();
        String address = addressField.getText();
        String room = roomField.getText();
        String regiDateString = regiDateField.getText();
        String phoneNumString = phoneNumberField.getText();
        String contactString = contactField.getText();
        
        int id = Integer.parseInt(idString);
        int age = Integer.parseInt(ageString);
        long phoneNum = Long.parseLong(phoneNumString);
        long contactNum = Long.parseLong(contactString);
        Date DOB = Date.valueOf(dobString);
        Date regiDate = Date.valueOf(regiDateString);
        
        patient.setId(id);
        patient.setFirstName(fname);
        patient.setLastName(lname);
        patient.setSex(sex);
        patient.setAge(age);
        patient.setDOB(DOB);
        patient.setMaritalStatus(maritalStatus);
        patient.setAddress(address);
        patient.setRoom(room);
        patient.setRegistrationDate(regiDate);
        patient.setPhoneNumber(phoneNum);
        patient.setContact(contactNum);
    }
    
    private void doEdit() {
        try {
            PatientDB.update(patient);
            dispose();
            fireDatebaseUpdatedEvent();
        } catch (DBException e) {
            System.out.println(e);
        }
    }
    
    private void doAdd() {
        try {
            PatientDB.add(patient);
            dispose();
            fireDatebaseUpdatedEvent();
        } catch (DBException e) {
            System.out.println(e);
        }
    }
    
    private void fireDatebaseUpdatedEvent() {
        PatientManagerFrame mainWindow = (PatientManagerFrame) getOwner();
        mainWindow.fireDatabaseUpdatedEvent();
    }
}
