package hospital.ui;

import java.util.List;
import javax.swing.table.AbstractTableModel;

import hospital.business.Patient;
import hospital.db.PatientDB;
import hospital.db.DBException;


/**
 *
 * @author junthearith
 */
public class PatientTableModel extends AbstractTableModel {
    private List<Patient> patients;
    private final String[] COLUMN_NAMES = {"PatientID", "PatientName", "Sex", 
        "Age", "DateOfBirth", "MaritalStatus", "Address", "Room", 
        "RegistrationDate", "PhoneNumber", "FamilyContact"};
    
    public PatientTableModel(){
        try {
            patients = PatientDB.getAll();
        } catch (DBException e) {
            System.out.println(e);
        }
    }

    @Override
    public int getRowCount() {
        return patients.size();
    }

    @Override
    public int getColumnCount() {
       return COLUMN_NAMES.length;
    }
    
    @Override
    public String getColumnName(int columnIndex) {
        return COLUMN_NAMES[columnIndex];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex) {
            case 0:
                return patients.get(rowIndex).getId();
            case 1: 
                return patients.get(rowIndex).getName();
            case 2: 
                return patients.get(rowIndex).getSex();
            case 3: 
                return patients.get(rowIndex).getAge();
            case 4:
                return patients.get(rowIndex).getDOB();
            case 5:
                return patients.get(rowIndex).getMaritalStatus();
            case 6:
                return patients.get(rowIndex).getAddress();
            case 7:
                return patients.get(rowIndex).getRoom();
            case 8:
                return patients.get(rowIndex).getRegistrationDate();
            case 9:
                return patients.get(rowIndex).getPhoneNumber();
            case 10: 
                return patients.get(rowIndex).getContact();
            default :
                return null;
        }
    }
    
    Patient getPatient(int rowIndex) {
        return patients.get(rowIndex);
    }
    
    void databaseUpdated() {
        try {
            patients = PatientDB.getAll();
            fireTableDataChanged();
        } catch (DBException e) {
            System.out.println(e);
        }
    }
}
