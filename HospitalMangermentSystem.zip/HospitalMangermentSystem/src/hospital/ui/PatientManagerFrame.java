package hospital.ui;

import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;

import hospital.business.Patient;
import hospital.db.DBException;
import hospital.db.PatientDB;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

/**
 *
 * @author junthearith
 */
public class PatientManagerFrame extends JFrame {
    private JTable patientTable;
    private PatientTableModel patientTableModel;
    
    public PatientManagerFrame() {
        try {
            UIManager.setLookAndFeel(
            UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException | InstantiationException | 
                 IllegalAccessException | UnsupportedLookAndFeelException e) {
            System.out.println(e);
        }
        
        setTitle("PatientManagerSystem");
        setSize(1200, 600);
        setLocationByPlatform(true);
        //setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        add(buildButtonPanel(), BorderLayout.NORTH);
        patientTable = buildPatientTable();
        add(new JScrollPane(patientTable), BorderLayout.CENTER);
        setVisible(true);
    }
    
    private JPanel buildButtonPanel() {
        JPanel panel = new JPanel();
        
        JButton addButton = new JButton("Add");
        addButton.setToolTipText("Add new patient");
        addButton.addActionListener((ActionEvent) -> {
            doAddButton();
        });
        panel.add(addButton);
        
        JButton editButton = new JButton("Edit");
        editButton.setToolTipText("Edit selected patient");
        editButton.addActionListener((ActionEvent) -> {
            doEditButton();
        });
        panel.add(editButton);
        
        JButton deleteButton = new JButton("Delete");
        deleteButton.setToolTipText("Delete selected patent");
        deleteButton.addActionListener((ActionEvent) -> {
            doDeleteButton();
        });
        panel.add(deleteButton);
        
        return panel;
    }
    
    private void doAddButton() {
        PatientForm patientForm = new PatientForm(this, "Add Patient", true);
        patientForm.setLocationRelativeTo(this);
        patientForm.setVisible(true);
    }
    
    private void doEditButton() {
        int selectRow = patientTable.getSelectedRow();
        if (selectRow == -1) {
            JOptionPane.showMessageDialog(this, 
                    "No patient is currently selected.",
                    "No patient selected", JOptionPane.INFORMATION_MESSAGE);
        } else {
            Patient patient = patientTableModel.getPatient(selectRow);
            PatientForm patientForm = 
                    new PatientForm(this, "Edit Patient", true, patient);
            patientForm.setLocationRelativeTo(this);
            patientForm.setVisible(true);
        }
    }
    
    private void doDeleteButton() {
        int selectedRow = patientTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, 
                    "No patient is corrently selected.", 
                    "No patient selected", JOptionPane.INFORMATION_MESSAGE);
        } else {
            Patient patient = patientTableModel.getPatient(selectedRow);
            int ask = JOptionPane.showConfirmDialog(this, 
                    "Are you sure want to delete " + 
                            patient.getName() + " from the database?", 
                    "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (ask == JOptionPane.YES_OPTION) {
                try {
                    PatientDB.delete(patient);
                    fireDatabaseUpdatedEvent();
                } catch (DBException e) {
                    System.out.println(e);
                }
            }
        }
    }
    
    private JTable buildPatientTable() {
        patientTableModel = new PatientTableModel();
        JTable table = new JTable(patientTableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setBorder(null);
        return table;
    }
    
    void fireDatabaseUpdatedEvent() {
        patientTableModel.databaseUpdated();
    }
}
