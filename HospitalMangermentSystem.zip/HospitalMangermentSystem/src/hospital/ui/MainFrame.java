package hospital.ui;

import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 *
 * @author junthearith
 */
public class MainFrame extends JFrame {
    
    public MainFrame() {
        try {
            UIManager.setLookAndFeel(
            UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException | InstantiationException | 
                 IllegalAccessException | UnsupportedLookAndFeelException e) {
            System.out.println(e);
        }
        
        setTitle("Hospital Managerment System");
        setSize(768, 384);
        setLocationByPlatform(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        add(buildButtonPanel(), BorderLayout.NORTH);
        
        setVisible(true);
    }
    
    private JPanel buildButtonPanel() {
        JPanel panel = new JPanel();
        
        JButton patientButton = new JButton("Patient");
        patientButton.addActionListener((ActionEvent) -> {
            patientButton();
        });
        panel.add(patientButton);
        
        JButton staffButton = new JButton("Staff");
        staffButton.addActionListener((ActionEvent) -> {
            staffButton();
        });
        panel.add(staffButton);
        
        return panel;
    }
    
    private void patientButton() {
        PatientManagerFrame patientFrame = new PatientManagerFrame();
        patientFrame.setLocationRelativeTo(this);
        patientFrame.setVisible(true);
    }
    
    private void staffButton() {
        StaffManagerFrame staffFrame = new StaffManagerFrame();
        staffFrame.setLocationRelativeTo(this);
        staffFrame.setVisible(true);
    }
}
