package hospital.ui;

import java.util.List;
import javax.swing.table.AbstractTableModel;

import hospital.business.Staff;
import hospital.db.StaffDB;
import hospital.db.DBException;
/**
 *
 * @author junthearith
 */
public class StaffTableModel extends AbstractTableModel {
    private List<Staff> staffs;
    private final String[] COLUMN_NAMES = {"StaffID", "StaffName", "Sex", 
        "Age", "DateOfBirth", "MaritalStatus", "Address", "City", "Positions", 
        "JoiningDate", "NationalID", "PhoneNumber", "Email"};
    
    public StaffTableModel(){
        try {
            staffs = StaffDB.getAllStaff();
        } catch (DBException e) {
            System.out.println(e);
        }
    }

    @Override
    public int getRowCount() {
        return staffs.size();
    }

    @Override
    public int getColumnCount() {
       return COLUMN_NAMES.length;
    }
    
    @Override
    public String getColumnName(int columnIndex) {
        return COLUMN_NAMES[columnIndex];
    }
    
    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex) {
            case 0:
                return staffs.get(rowIndex).getId();
            case 1: 
                return staffs.get(rowIndex).getName();
            case 2: 
                return staffs.get(rowIndex).getSex();
            case 3: 
                return staffs.get(rowIndex).getAge();
            case 4:
                return staffs.get(rowIndex).getDOB();
            case 5:
                return staffs.get(rowIndex).getMaritalStatus();
            case 6:
                return staffs.get(rowIndex).getAddress();
            case 7:
                return staffs.get(rowIndex).getCity();
            case 8:
                return staffs.get(rowIndex).getPositions();
            case 9:
                return staffs.get(rowIndex).getJoiningDate();
            case 10:
                return staffs.get(rowIndex).getNationalID();
            case 11:
                return staffs.get(rowIndex).getPhoneNumber();
            case 12: 
                return staffs.get(rowIndex).getEmail();
            default :
                return null;
        }
    }
    
    Staff getStaff(int rowIndex) {
        return staffs.get(rowIndex);
    }
    
    void databaseUpdated() {
        try {
            staffs = StaffDB.getAllStaff();
            fireTableDataChanged();
        } catch (DBException e) {
            System.out.println(e);
        }
    }
}
