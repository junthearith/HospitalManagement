package hospital.ui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.JPanel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.WindowConstants;
import java.sql.Date;

import hospital.business.Staff;
import hospital.db.StaffDB;
import hospital.db.DBException;
/**
 *
 * @author junthearith
 */
public class StaffForm extends JDialog {
    private JTextField staffIdField;
    private JTextField firstNameField;
    private JTextField lastNameField;
    private JTextField sexField;
    private JTextField ageField;
    private JTextField dobField;
    private JTextField maritalStatusField;
    private JTextField addressField;
    private JTextField cityField;
    private JTextField joiningDateField;
    private JTextField positionsField;
    private JTextField nationalIdField;
    private JTextField phoneNumberField;
    private JTextField emailField;
    private JButton confirmButton;
    private JButton cancelButton;
    
    private Staff staff = new Staff();
    
    public StaffForm(java.awt.Frame parent, String title, boolean modal) {
        super(parent, title, modal);
        initComponents();
    }
    
    public StaffForm(java.awt.Frame parent, String title, boolean modal, 
            Staff staff) {
        this(parent, title, modal);
        this.staff = staff;
        confirmButton.setText("Save");
        
        // set Data to textField
        staffIdField.setText(Integer.toString(staff.getId()));
        firstNameField.setText(staff.getFirstName());
        lastNameField.setText(staff.getLastName());
        sexField.setText(staff.getSex());
        ageField.setText(Integer.toString(staff.getAge()));
        dobField.setText(staff.getStringDOB());
        maritalStatusField.setText(staff.getMaritalStatus());
        addressField.setText(staff.getAddress());
        cityField.setText(staff.getCity());
        joiningDateField.setText(staff.getStringJoiningDate());
        positionsField.setText(staff.getPositions());
        nationalIdField.setText(Long.toString(staff.getNationalID()));
        phoneNumberField.setText(Long.toString(staff.getPhoneNumber()));
        emailField.setText(staff.getEmail());
        
        staffIdField.setEditable(false);
    }
    
    private void initComponents() {
        staffIdField = new JTextField();
        firstNameField = new JTextField();
        lastNameField = new JTextField();
        sexField = new JTextField();
        ageField = new JTextField();
        dobField = new JTextField();
        maritalStatusField = new JTextField();
        addressField = new JTextField();
        cityField = new JTextField();
        joiningDateField = new JTextField();
        positionsField = new JTextField();
        nationalIdField = new JTextField();
        phoneNumberField = new JTextField();
        emailField = new JTextField();
        confirmButton = new JButton();
        cancelButton = new JButton();
        
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        
        Dimension shortField = new Dimension(150, 20);
        Dimension longField = new Dimension(200, 20);
        
        staffIdField.setPreferredSize(shortField);
        staffIdField.setMinimumSize(shortField);
        firstNameField.setPreferredSize(longField);
        firstNameField.setMinimumSize(longField);
        lastNameField.setPreferredSize(longField);
        lastNameField.setMinimumSize(longField);
        sexField.setPreferredSize(shortField);
        sexField.setMinimumSize(shortField);
        ageField.setPreferredSize(shortField);
        ageField.setMinimumSize(shortField);
        dobField.setPreferredSize(longField);
        dobField.setMinimumSize(longField);
        maritalStatusField.setPreferredSize(longField);
        maritalStatusField.setMinimumSize(longField);
        addressField.setPreferredSize(longField);
        addressField.setMinimumSize(longField);
        cityField.setPreferredSize(shortField);
        cityField.setMinimumSize(shortField);
        joiningDateField.setPreferredSize(longField);
        joiningDateField.setMinimumSize(longField);
        positionsField.setPreferredSize(longField);
        positionsField.setMinimumSize(longField);
        nationalIdField.setPreferredSize(longField);
        nationalIdField.setMinimumSize(longField);
        phoneNumberField.setPreferredSize(longField);
        phoneNumberField.setMinimumSize(longField);
        emailField.setPreferredSize(longField);
        emailField.setMinimumSize(longField);
        
        cancelButton.setText("Cancel");
        cancelButton.addActionListener((ActionEvent) -> {
            cancelButtonActionPerformed();
        });
        
        confirmButton.setText("Add");
        confirmButton.addActionListener((ActionEvent) -> {
            confirmButtonActionPerformed();
        });
        
        JPanel staffPanel = new JPanel();
        staffPanel.setLayout(new GridBagLayout());
        staffPanel.add(new JLabel("ID:"),
                getConstraints(0, 0, GridBagConstraints.LINE_START));
        staffPanel.add(staffIdField,
                getConstraints(1, 0, GridBagConstraints.LINE_START));
        staffPanel.add(new JLabel("FirstName:"),
                getConstraints(0, 1, GridBagConstraints.LINE_START));
        staffPanel.add(firstNameField,
                getConstraints(1, 1, GridBagConstraints.LINE_START));
        staffPanel.add(new JLabel("LastName:"), 
                getConstraints(0, 2, GridBagConstraints.LINE_START));
        staffPanel.add(lastNameField, 
                getConstraints(1, 2, GridBagConstraints.LINE_START));
        staffPanel.add(new JLabel("Sex:"), 
                getConstraints(0, 3, GridBagConstraints.LINE_START));
        staffPanel.add(sexField, 
                getConstraints(1, 3, GridBagConstraints.LINE_START));
        staffPanel.add(new JLabel("Age:"), 
                getConstraints(0, 4, GridBagConstraints.LINE_START));
        staffPanel.add(ageField, 
                getConstraints(1, 4, GridBagConstraints.LINE_START));
        staffPanel.add(new JLabel("DOB(yyyy-mm-dd):"), 
                getConstraints(0, 5, GridBagConstraints.LINE_START));
        staffPanel.add(dobField, 
                getConstraints(1, 5, GridBagConstraints.LINE_START));
        staffPanel.add(new JLabel("MaritalStatus:"), 
                getConstraints(0, 6, GridBagConstraints.LINE_START));
        staffPanel.add(maritalStatusField, 
                getConstraints(1, 6, GridBagConstraints.LINE_START));
        staffPanel.add(new JLabel("Address:"), 
                getConstraints(3, 0, GridBagConstraints.LINE_START));
        staffPanel.add(addressField, 
                getConstraints(4, 0, GridBagConstraints.LINE_START));
        staffPanel.add(new JLabel("City:"), 
                getConstraints(3, 1, GridBagConstraints.LINE_START));
        staffPanel.add(cityField, 
                getConstraints(4, 1, GridBagConstraints.LINE_START));
        staffPanel.add(new JLabel("JoiningDate(yyyy-mm-dd):"), 
                getConstraints(3, 2, GridBagConstraints.LINE_START));
        staffPanel.add(joiningDateField, 
                getConstraints(4, 2, GridBagConstraints.LINE_START));
        staffPanel.add(new JLabel("Positions:"), 
                getConstraints(3, 3, GridBagConstraints.LINE_START));
        staffPanel.add(positionsField, 
                getConstraints(4, 3, GridBagConstraints.LINE_START));
        staffPanel.add(new JLabel("NationalID:"), 
                getConstraints(3, 4, GridBagConstraints.LINE_START));
        staffPanel.add(nationalIdField, 
                getConstraints(4, 4, GridBagConstraints.LINE_START));
        staffPanel.add(new JLabel("PhoneNumber:"), 
                getConstraints(3, 5, GridBagConstraints.LINE_START));
        staffPanel.add(phoneNumberField, 
                getConstraints(4, 5, GridBagConstraints.LINE_START));
        staffPanel.add(new JLabel("Email:"), 
                getConstraints(3, 6, GridBagConstraints.LINE_START));
        staffPanel.add(emailField, 
                getConstraints(4, 6, GridBagConstraints.LINE_START));
        
        // JButton panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(confirmButton);
        buttonPanel.add(cancelButton);
        
        // add panel to main panel
        setLayout(new BorderLayout());
        add(staffPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);
        pack();
    }
    
    private GridBagConstraints getConstraints(int x, int y, int anchor) {
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(5, 5, 0, 5);
        c.gridx = x; c.gridy = y; c.anchor = anchor;
        return c;
    }
    
    private void cancelButtonActionPerformed() {
        dispose();
    }
    
    private void confirmButtonActionPerformed() {
        if (isValidDateData()) {
            setData();
            if (confirmButton.getText().equals("Add")) {
                doAdd();
            } 
            else {
                doEdit();
            }
        }
    }
    
    private boolean isValidDateData() {
        String idString = staffIdField.getText();
        String fname = firstNameField.getText();
        String lname = lastNameField.getText();
        String sex = sexField.getText();
        String ageString = ageField.getText();
        String dobString = dobField.getText();
        String maritalStatus = maritalStatusField.getText();
        String address = addressField.getText();
        String city = cityField.getText();
        String positions = positionsField.getText();
        String joiningDateString = joiningDateField.getText();
        String nationalIDString = nationalIdField.getText();
        String phoneNumString = phoneNumberField.getText();
        String emailString = emailField.getText();
        
        if (idString == null || fname == null || lname == null || sex == null || 
                ageString == null || maritalStatus == null || address == null ||
                city == null || positions == null || joiningDateString == null || 
                phoneNumString == null || emailString == null || idString.isEmpty() || 
                fname.isEmpty() || lname.isEmpty() || sex.isEmpty() || ageString.isEmpty() || 
                maritalStatus.isEmpty() || address.isEmpty() || city.isEmpty() || 
                positions.isEmpty() || joiningDateString.isEmpty() || phoneNumString.isEmpty() || 
                emailString.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.", 
                    "Missing Fields", JOptionPane.INFORMATION_MESSAGE);
            return false;
        } 
        else {
            try {
                int age = Integer.parseInt(ageString);
                long nationalId = Long.parseLong(nationalIDString);
                long phoneNum = Long.parseLong(phoneNumString);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, 
                        "This data entered is invalid.", 
                        "Invalid Numberic", JOptionPane.INFORMATION_MESSAGE);
                //requestFocusInWindow();
                return false;
            }
            
            try {
                Date DOB = Date.valueOf(dobString);
                Date joiningDate = Date.valueOf(joiningDateString);
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, 
                        "This LocalDate parse entered is invalid.", 
                        "LocalDate parse Invalid.", JOptionPane.INFORMATION_MESSAGE);
                //requestFocusInWindow();
                return false;
            }
        }
        return true;
    }
    
    private void setData() {
        String idString = staffIdField.getText();
        String fname = firstNameField.getText();
        String lname = lastNameField.getText();
        String sex = sexField.getText();
        String ageString = ageField.getText();
        String dobString = dobField.getText();
        String maritalStatus = maritalStatusField.getText();
        String address = addressField.getText();
        String city = cityField.getText();
        String positions = positionsField.getText();
        String joiningDateString = joiningDateField.getText();
        String nationalIdString = nationalIdField.getText();
        String phoneNumString = phoneNumberField.getText();
        String email = emailField.getText();
        
        int id = Integer.parseInt(idString);
        int age = Integer.parseInt(ageString);
        long phoneNum = Long.parseLong(phoneNumString);
        long nationalId = Long.parseLong(nationalIdString);
        Date DOB = Date.valueOf(dobString);
        Date joiningDate = Date.valueOf(joiningDateString);
        
        staff.setId(id);
        staff.setFirstName(fname);
        staff.setLastName(lname);
        staff.setSex(sex);
        staff.setAge(age);
        staff.setDOB(DOB);
        staff.setMaritalStatus(maritalStatus);
        staff.setAddress(address);
        staff.setCity(city);
        staff.setPositions(positions);
        staff.setJoiningDate(joiningDate);
        staff.setNationalID(nationalId);
        staff.setPhoneNumber(phoneNum);
        staff.setEmail(email);
    }
    
    private void doEdit() {
        try {
            StaffDB.update(staff);
            dispose();
            fireDatebaseUpdatedEvent();
        } catch (DBException e) {
            System.out.println(e);
        }
    }
    
    private void doAdd() {
        try {
            StaffDB.add(staff);
            dispose();
            fireDatebaseUpdatedEvent();
        } catch (DBException e) {
            System.out.println(e);
        }
    }
    
    private void fireDatebaseUpdatedEvent() {
        StaffManagerFrame mainWindow = (StaffManagerFrame) getOwner();
        mainWindow.fireDatabaseUpdatedEvent();
    }
}
