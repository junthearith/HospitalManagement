package hospital.ui;

import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;

import hospital.business.Staff;
import hospital.db.DBException;
import hospital.db.PatientDB;
import hospital.db.StaffDB;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
/**
 *
 * @author junthearith
 */
public class StaffManagerFrame extends JFrame {
    private JTable staffTable;
    private StaffTableModel staffTableModel;
    
    public StaffManagerFrame() {
        try {
            UIManager.setLookAndFeel(
            UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException | InstantiationException | 
                 IllegalAccessException | UnsupportedLookAndFeelException e) {
            System.out.println(e);
        }
        
        setTitle("StaffManagerSystem");
        setSize(1200, 600);
        setLocationByPlatform(true);
        //setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        add(buildButtonPanel(), BorderLayout.NORTH);
        staffTable = buildStaffTable();
        add(new JScrollPane(staffTable), BorderLayout.CENTER);
        setVisible(true);
    }
    
    private JPanel buildButtonPanel() {
        JPanel panel = new JPanel();
        
        JButton addButton = new JButton("Add");
        addButton.setToolTipText("Add new staff");
        addButton.addActionListener((ActionEvent) -> {
            doAddButton();
        });
        panel.add(addButton);
        
        JButton editButton = new JButton("Edit");
        editButton.setToolTipText("Edit selected staff");
        editButton.addActionListener((ActionEvent) -> {
            doEditButton();
        });
        panel.add(editButton);
        
        JButton deleteButton = new JButton("Delete");
        deleteButton.setToolTipText("Delete selected staff");
        deleteButton.addActionListener((ActionEvent) -> {
            doDeleteButton();
        });
        panel.add(deleteButton);
        
        return panel;
    }
    
    private void doAddButton() {
        StaffForm staffForm = new StaffForm(this, "Add Staff", true);
        staffForm.setLocationRelativeTo(this);
        staffForm.setVisible(true);
    }
    
    private void doEditButton() {
        int selectRow = staffTable.getSelectedRow();
        if (selectRow == -1) {
            JOptionPane.showMessageDialog(this, 
                    "No patient is currently selected.",
                    "No patient selected", JOptionPane.INFORMATION_MESSAGE);
        } else {
            Staff staff = staffTableModel.getStaff(selectRow);
            StaffForm staffForm = 
                    new StaffForm(this, "Edit Staff", true, staff);
            staffForm.setLocationRelativeTo(this);
            staffForm.setVisible(true);
        }
    }
    
    private void doDeleteButton() {
        int selectedRow = staffTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, 
                    "No staff is currently selected.", 
                    "No staff selected", JOptionPane.INFORMATION_MESSAGE);
        } else {
            Staff staff = staffTableModel.getStaff(selectedRow);
            int ask = JOptionPane.showConfirmDialog(this, 
                    "Are you sure want to delete " + 
                            staff.getName() + " from the database", 
                    "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (ask == JOptionPane.YES_OPTION) {
                try {
                    StaffDB.delete(staff);
                    fireDatabaseUpdatedEvent();
                } catch (DBException e) {
                    System.out.println(e);
                }
            }
        }
    }
    
    private JTable buildStaffTable() {
        staffTableModel = new StaffTableModel();
        JTable table = new JTable(staffTableModel);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.setBorder(null);
        return table;
    }
    
    void fireDatabaseUpdatedEvent() {
        staffTableModel.databaseUpdated();
    }
}
