package hospital.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import hospital.business.Staff;
import java.sql.Date;
/**
 *
 * @author junthearith
 */
public class StaffDB {
     
    public static List<Staff> getAllStaff() throws DBException {
        String sql = "SELECT * FROM Staff ORDER BY StaffID";
        List<Staff> staffs = new ArrayList<>();
        Connection connection = DBUtil.getConnection();
        try (PreparedStatement ps = connection.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                int staffId = rs.getInt("StaffID");
                String fname = rs.getString("FirstName");
                String lname = rs.getString("LastName");
                String sex = rs.getString("Sex");
                int age = rs.getInt("Age");
                Date dateOfBirth = rs.getDate("DateOfBirth");
                String maritalStatus = rs.getString("MaritalStatus");
                String address = rs.getString("Address");
                String city = rs.getString("City");
                String positions = rs.getString("Positions");
                Date joiningDate = rs.getDate("JoiningDate");
                long nationalID = rs.getLong("NationalID");
                long phoneNumber = rs.getLong("PhoneNumber");
                String email = rs.getString("Email");
                
                Staff s = new Staff();
                s.setId(staffId);
                s.setFirstName(fname);
                s.setLastName(lname);
                s.setSex(sex);
                s.setAge(age);
                s.setDOB(dateOfBirth);
                s.setMaritalStatus(maritalStatus);
                s.setAddress(address);
                s.setCity(city);
                s.setPositions(positions);
                s.setJoiningDate(joiningDate);
                s.setNationalID(nationalID);
                s.setPhoneNumber(phoneNumber);
                s.setEmail(email);
                staffs.add(s);
            }
            return staffs;
        } catch (SQLException e) {
            throw new DBException(e);
        }
    }
    
    public static void add(Staff staff) throws DBException {
        String sql 
                = "INSERT INTO Staff (StaffID, FirstName, LastName, Sex, "
                + "Age, DateOfBirth, MaritalStatus, Address, City, Positions, "
                + "JoiningDate, NationalID, PhoneNumber, Email)" 
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        Connection connection = DBUtil.getConnection();
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, staff.getId());
            ps.setString(2, staff.getFirstName());
            ps.setString(3, staff.getLastName());
            ps.setString(4, staff.getSex());
            ps.setInt(5, staff.getAge());
            ps.setDate(6, staff.getDOB());
            ps.setString(7, staff.getMaritalStatus());
            ps.setString(8, staff.getAddress());
            ps.setString(9, staff.getCity());
            ps.setString(10, staff.getPositions());
            ps.setDate(11, staff.getJoiningDate());
            ps.setLong(12, staff.getNationalID());
            ps.setLong(13, staff.getPhoneNumber());
            ps.setString(14, staff.getEmail());
            ps.executeUpdate();
            
        } catch (SQLException e) {
            throw new DBException(e);
        }
    }
    
    public static void update(Staff staff) throws DBException {
        String sql 
                = "UPDATE Staff SET "
                + "FirstName = ?, "
                + "Lastname = ?, "
                + "Sex = ?, "
                + "Age = ?, " 
                + "DateOfBirth = ?, "
                + "MaritalStatus = ?, "
                + "Address = ?, "
                + "City = ?, "
                + "Positions = ?, "
                + "JoiningDate = ?, "
                + "NationalID = ?, "
                + "PhoneNumber = ?, "
                + "Email = ? "
                + "WHERE StaffID = ? ";
        Connection connection = DBUtil.getConnection();
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, staff.getFirstName());
            ps.setString(2, staff.getLastName());
            ps.setString(3, staff.getSex());
            ps.setInt(4, staff.getAge());
            ps.setDate(5, staff.getDOB());
            ps.setString(6, staff.getMaritalStatus());
            ps.setString(7, staff.getAddress());
            ps.setString(8, staff.getCity());
            ps.setString(9, staff.getPositions());
            ps.setDate(10, staff.getJoiningDate());
            ps.setLong(11, staff.getNationalID());
            ps.setLong(12, staff.getPhoneNumber());
            ps.setString(13, staff.getEmail());
            ps.setInt(14, staff.getId());
            ps.executeUpdate();
            
        } catch (SQLException e) {
            throw new DBException(e);
        }
    }
    
    public static void delete(Staff staff) throws DBException {
        String sql 
                = "DELETE FROM Staff " 
                + "WHERE StaffID = ?";
        Connection connection = DBUtil.getConnection();
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, staff.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new DBException(e);
        }
    }
}
