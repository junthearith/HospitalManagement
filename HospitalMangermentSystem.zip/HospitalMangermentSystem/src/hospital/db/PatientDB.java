package hospital.db;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import hospital.business.Patient;
import java.sql.Date;
/**
 *
 * @author junthearith
 */
public class PatientDB {
    
    public static List<Patient> getAll() throws DBException {
        String sql = "SELECT * FROM Patient ORDER BY FirstName";
        List<Patient> patients = new ArrayList<>();
        Connection connection = DBUtil.getConnection();
        try (PreparedStatement ps = connection.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                int PatientID = rs.getInt("PatientID");
                String fname = rs.getString("FirstName");
                String lname = rs.getString("LastName");
                String sex = rs.getString("Sex");
                int age = rs.getInt("Age");
                Date dateOfBirth = rs.getDate("DateOfBirth");
                String maritalStatus = rs.getString("MaritalStatus");
                String address = rs.getString("Address");
                String room = rs.getString("Room");
                Date regiDate = rs.getDate("RegistrationDate");
                long phoneNumber = rs.getLong("PhoneNumber");
                long contact = rs.getLong("FamilyContact");
                
                Patient p = new Patient();
                p.setId(PatientID);
                p.setFirstName(fname);
                p.setLastName(lname);
                p.setSex(sex);
                p.setAge(age);
                p.setDOB(dateOfBirth);
                p.setMaritalStatus(maritalStatus);
                p.setAddress(address);
                p.setRoom(room);
                p.setRegistrationDate(regiDate);
                p.setPhoneNumber(phoneNumber);
                p.setContact(contact);
                patients.add(p);
            }
            return patients;
        } catch (SQLException e) {
            throw new DBException(e);
        }
    }
    
    public static Patient get(int patientID) throws DBException {
        String sql = "SELECT * FROM Patient WHERE PatientID = ?";
        Connection connection = DBUtil.getConnection();
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, patientID);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                //int PatientID = rs.getInt("PatientID");
                String fname = rs.getString("FirstName");
                String lname = rs.getString("LastName");
                String sex = rs.getString("Sex");
                int age = rs.getInt("Age");
                Date dateOfBirth = rs.getDate("DateOfBirth");
                String maritalStatus = rs.getString("MaritalStatus");
                String address = rs.getString("Address");
                String room = rs.getString("Room");
                Date regiDate = rs.getDate("RegistrationDate");
                long phoneNumber = rs.getLong("PhoneNumber");
                long contact = rs.getLong("FamilyContact");
                rs.close();
                
                Patient p = new Patient();
                //p.setId(PatientID);
                p.setFirstName(fname);
                p.setLastName(lname);
                p.setSex(sex);
                p.setAge(age);
                p.setDOB(dateOfBirth);
                p.setMaritalStatus(maritalStatus);
                p.setAddress(address);
                p.setRoom(room);
                p.setRegistrationDate(regiDate);
                p.setPhoneNumber(phoneNumber);
                p.setContact(contact);
                
                return p;
            } else {
                rs.close();
                return null;
            }
        } catch (SQLException e) {
            throw new DBException(e);
        }
    }
    
    public static void add(Patient patient) throws DBException {
        String sql 
                = "INSERT INTO Patient (PatientID, FirstName, LastName, Sex, "
                + "Age, DateOfBirth, MaritalStatus, Address, Room, "
                + "RegistrationDate, PhoneNumber, FamilyContact)" 
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        Connection connection = DBUtil.getConnection();
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, patient.getId());
            ps.setString(2, patient.getFirstName());
            ps.setString(3, patient.getLastName());
            ps.setString(4, patient.getSex());
            ps.setInt(5, patient.getAge());
            ps.setDate(6, patient.getDOB());
            ps.setString(7, patient.getMaritalStatus());
            ps.setString(8, patient.getAddress());
            ps.setString(9, patient.getRoom());
            ps.setDate(10, patient.getRegistrationDate());
            ps.setLong(11, patient.getPhoneNumber());
            ps.setLong(12, patient.getContact());
            ps.executeUpdate();
            
        } catch (SQLException e) {
            throw new DBException(e);
        }
    }
    
    public static void update(Patient patient) throws DBException {
        String sql 
                = "UPDATE Patient SET "
                + "FirstName = ?, "
                + "LastName = ?, " 
                + "Sex = ?, " 
                + "Age = ?, " 
                + "DateOfBirth = ?, " 
                + "MaritalStatus = ?, " 
                + "Address = ?, " 
                + "Room = ?, " 
                + "RegistrationDate = ?, " 
                + "PhoneNumber = ?, " 
                + "FamilyContact = ? "
                + "WHERE PatientID = ?";
        Connection connection = DBUtil.getConnection();
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, patient.getFirstName());
            ps.setString(2, patient.getLastName());
            ps.setString(3, patient.getSex());
            ps.setInt(4, patient.getAge());
            ps.setDate(5, patient.getDOB());
            ps.setString(6, patient.getMaritalStatus());
            ps.setString(7, patient.getAddress());
            ps.setString(8, patient.getRoom());
            ps.setDate(9, patient.getRegistrationDate());
            ps.setLong(10, patient.getPhoneNumber());
            ps.setLong(11, patient.getContact());
            ps.setInt(12, patient.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new DBException(e);
        }
    }
    
    public static void delete(Patient patient) throws DBException {
        String sql = "DELETE FROM Patient " 
                   + "WHERE PatientID = ?";
        Connection connection = DBUtil.getConnection();
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, patient.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new DBException(e);
        }
    }
}
