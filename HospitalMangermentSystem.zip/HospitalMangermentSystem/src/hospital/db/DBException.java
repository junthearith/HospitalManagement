
package hospital.db;

/**
 *
 * @author junthearith
 */
public class DBException extends Exception {
    DBException() {}
    
    DBException(Exception e) {
        super(e);
    }
}
