package hospital.business;

import java.sql.Date;


/**
 *
 * @author junthearith
 */
public class Patient extends Person {
    
    private String room;
    
    private Date registrationDate;
    private long contact;
    
    public String getRoom() {
        return room;
    }
    public void setRoom(String room) {
        this.room = room;
    }
    
    public Date getRegistrationDate() {
        return registrationDate;
    }
    public void setRegistrationDate(Date registrationDate) {
        this.registrationDate = registrationDate;
    }
    
    public long getContact() {
        return contact;
    }
    public void setContact(long contact) {
        this.contact = contact;
    }
    
    public String getStringRegiDate() {
        return String.valueOf(getRegistrationDate());
    }
}
