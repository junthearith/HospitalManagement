package hospital.business;

//import java.util.Date;
import java.sql.Date;
/**
 *
 * @author junthearith
 */
public class Person {
    
    private int id;
    private int age;
    private String fname;
    private String lname;
    private String sex;
    private Date dateOfBirth;
    private String maritalStatus;
    private String address;
    private long phoneNumber;
    
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    
    public String getFirstName() {
        return fname;
    }
    public void setFirstName(String fname) {
        this.fname = fname;
    }
    
    public String getLastName() {
        return lname;
    }
    public void setLastName(String lname) {
        this.lname = lname;
    }
        
    public String getSex() {
        return sex;
    }
    public void setSex(String sex) {
        this.sex = sex;
    }
    
    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }
    
    public Date getDOB() {
        return dateOfBirth;
    }
    public void setDOB(Date dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }
    
    public String getMaritalStatus() {
        return maritalStatus;
    }
    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }
    
    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }
    
    public long getPhoneNumber() {
        return phoneNumber;
    }
    public void setPhoneNumber(long phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    
    public String getName() {
        return fname + " " + lname;
    }
    
    public String getStringDOB() {
        return String.valueOf(getDOB());
    }
    
}
