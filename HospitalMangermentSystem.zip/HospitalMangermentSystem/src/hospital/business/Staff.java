package hospital.business;

import java.sql.Date;
/**
 *
 * @author junthearith
 */
public class Staff extends Person {
    
    private String city;
    private String positions;
    private Date joiningDate;
    private long nationalId;
    private String email;
        
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    
    public String getPositions() {
        return positions;
    }
    public void setPositions(String positions) {
        this.positions = positions;
    }
    
    public Date getJoiningDate() {
        return joiningDate;
    }
    public void setJoiningDate(Date joiningDate) {
        this.joiningDate = joiningDate;
    }
    
    public long getNationalID() {
        return nationalId;
    }
    public void setNationalID(long nationalID) {
        this.nationalId = nationalID;
    }
    
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getStringJoiningDate() {
        return String.valueOf(getJoiningDate());
    }
}
