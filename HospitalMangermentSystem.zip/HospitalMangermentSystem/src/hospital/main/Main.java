package hospital.main;

import hospital.ui.MainFrame;
import hospital.ui.PatientManagerFrame;
import hospital.ui.StaffManagerFrame;

/**
 *
 * @author junthearith
 */
public class Main {
    public static void main(String[] args) {
        new MainFrame();
    }
}
