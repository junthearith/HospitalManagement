-- USE hospital
-- DROP TABLE Staff


/*CREATE TABLE Staff (
	StaffID				INT(6)			unsigned 	PRIMARY KEY,
    FirstName			VARCHAR(18)		NOT NULL,
    LastName			VARCHAR(24)		NOT NULL,
    Sex					VARCHAR(12)		NOT NULL,
    Age					TINYINT			NOT NULL,
    DateOfBirth			DATE,
    MaritalStatus		VARCHAR(20),
    Address				VARCHAR(40),
    City				VARCHAR(24)		NOT NULL,
    Positions			VARCHAR(40)		NOT NULL,
    JoiningDate			DATE,
	NationalID			BIGINT,
    PhoneNumber			BIGINT			UNIQUE,
    Email				VARCHAR(40)
);*/

/*INSERT INTO Staff VALUES 
('1', 'Chompa', 'Tepy', 'Female', '22','2000-4-22','Single', 'Battambang', 'Battambang', 'Nurse', '2022-10-05', '1711444555', '126669999', 'tepychompa@gmail.com'),
('2', 'OHH', 'NO', 'Female', '24', '1998-08-12', 'Married', 'PhnomPenh','PhnomPenh', 'Medical technologist', '2022-04-09', '1933337777', '88882222', 'ohhgodno@gmail.com');
*/