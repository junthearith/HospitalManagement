-- DROP DATABASE IF EXISTS hospital
-- CREATE DATABASE hospital
-- USE hospital

/*CREATE TABLE Patient (
	PatientID			INT(6)			unsigned		PRIMARY KEY,
    FirstName			VARCHAR(18)		NOT NULL,
    LastName			VARCHAR(24)		NOT NULL,
    Sex					VARCHAR(12)		NOT NULL,
    Age					TINYINT			NOT NULL,
    DateOfBirth			DATE,
    MaritalStatus		VARCHAR(20),
    Address				VARCHAR(40),
    Room				VARCHAR(12),
    RegistrationDate	DATE,
    PhoneNumber			BIGINT 			UNIQUE,
    FamilyContact		BIGINT
);*/

/*INSERT INTO Patient VALUES 
('1', 'Jun', 'Thearith', 'Male', '23','1998-11-22','Single', 'Battambang', 'A11', '2022-6-1', '44445555', '66669999'),
('2', 'Nice', 'Nona', 'Female', '24', '1999-06-15', 'Married', 'Phnom Penh','B156', '2022-6-3', '33337777', '88882222');
/*
-- create user
-- CREATE USER 'hospital_user'@'localhost' IDENTIFIED BY 'hospital'
