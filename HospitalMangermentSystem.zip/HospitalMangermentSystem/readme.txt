1. install java virtual machine
2. install j2se 17
3. install and config mysql
4. install mysqlworkbench
	create_hospital.sql and create_staff_table.sql
5. install Apache NetBeans17 ide
6. open project HospitalManagementSystem
7. import mysql-connector-java-8.0.29 to Libraries
8. Run Project
